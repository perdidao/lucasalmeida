// Lista de arquivo
$('.btn-datas').click(function(e){
    e.preventDefault();

    $('#arquivo').slideToggle();

});